These three files are versions of the Adafruit Fridge Logger.

See:

http://forums.adafruit.com/viewtopic.php?f=31&t=21844

http://www.ladyada.net/make/logshield/lighttemp.html


lighttemplogger.pde - version for the Arduino SD.h library

LightTempSdfat.pde - minimal changes to port to SdFat

LightTempStreams.pde - version using I/O streams

